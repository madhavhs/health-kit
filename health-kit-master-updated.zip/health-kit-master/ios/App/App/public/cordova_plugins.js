
  cordova.define('cordova/plugin_list', function(require, exports, module) {
    module.exports = [
      {
          "id": "cordova-open-native-settings.Settings",
          "file": "plugins/cordova-open-native-settings/www/settings.js",
          "pluginId": "cordova-open-native-settings",
        "clobbers": [
          "cordova.plugins.settings"
        ]
        },
      {
          "id": "cordova-plugin-background-fetch.BackgroundFetch",
          "file": "plugins/cordova-plugin-background-fetch/www/BackgroundFetch.js",
          "pluginId": "cordova-plugin-background-fetch",
        "clobbers": [
          "window.BackgroundFetch"
        ]
        },
      {
          "id": "com.telerik.plugins.healthkit.HealthKit",
          "file": "plugins/com.telerik.plugins.healthkit/www/HealthKit.js",
          "pluginId": "com.telerik.plugins.healthkit",
        "clobbers": [
          "window.plugins.healthkit"
        ]
        }
    ];
    module.exports.metadata =
    // TOP OF METADATA
    {
      "com.telerik.plugins.healthkit": "0.7.0",
      "cordova-open-native-settings": "1.5.5",
      "cordova-plugin-background-fetch": "7.0.3"
    };
    // BOTTOM OF METADATA
    });
    